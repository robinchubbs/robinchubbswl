import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import StatsBar from './components/StatsBar';
import About from './components/About';
import Collection from './components/Collection';
import Vision from './components/Vision';
import Roadmap from './components/Roadmap';
import CTA from './components/CTA';
import Footer from './components/Footer';
import WhitelistModal from './components/WhitelistModal';
import Toast, { type ToastState } from './components/Toast';
import Confetti from './components/Confetti';

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [confettiTrigger, setConfettiTrigger] = useState(0);

  const showToast = (message: string, isError = false) => {
    setToast({ message, isError, id: Date.now() });
  };

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  const handleSuccess = () => {
    setConfettiTrigger((t) => t + 1);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <main>
        <Hero onApply={openModal} />
        <StatsBar />
        <About />
        <Collection />
        <Vision />
        <Roadmap />
        <CTA onApply={openModal} />
      </main>

      <Footer />

      <WhitelistModal
        open={modalOpen}
        onClose={closeModal}
        onSuccess={handleSuccess}
        onToast={showToast}
      />

      <Toast toast={toast} />
      <Confetti trigger={confettiTrigger} />
    </div>
  );
}

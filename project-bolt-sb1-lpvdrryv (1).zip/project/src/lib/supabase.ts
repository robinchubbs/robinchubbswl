import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type WhitelistApplication = {
  id?: string;
  twitter: string;
  wallet_address: string;
  status?: string;
  created_at?: string;
};

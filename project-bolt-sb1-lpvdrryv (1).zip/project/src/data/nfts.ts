export type NFT = {
  name: string;
  image: string;
  number: string;
};

export const NFTS: NFT[] = [
  {
    name: 'Samurai Chubbs',
    image: 'https://i.ibb.co.com/vCSZ4bdQ/f7ad2cec-6c6d-4663-a872-1ca5a7ff28b5.jpg',
    number: '01',
  },
  {
    name: 'Cowboy Chubbs',
    image: 'https://i.ibb.co.com/S4WpPKwR/31bfc282-670f-46e0-b54a-afd1b17c93e7.jpg',
    number: '02',
  },
  {
    name: 'Ninja Chubbs',
    image: 'https://i.ibb.co.com/8L1pkcNz/4cd22737-d965-4bdf-8369-09ee8fa72745.jpg',
    number: '03',
  },
  {
    name: 'Astronaut Chubbs',
    image: 'https://i.ibb.co.com/sLcBm7p/dcbd2503-c02f-4f2b-af28-80764411b641.jpg',
    number: '04',
  },
  {
    name: 'King Chubbs',
    image: 'https://i.ibb.co.com/Vcnf1gnw/b9910834-eb46-480f-93d3-05938117b94a.jpg',
    number: '05',
  },
  {
    name: 'Pirate Chubbs',
    image: 'https://i.ibb.co.com/Dffj41k0/93e372ac-d4b1-4d37-8b96-3b0bfa48a326.jpg',
    number: '06',
  },
  {
    name: 'Wizard Chubbs',
    image: 'https://i.ibb.co.com/VW2P6PT4/b5fffd9f-ad80-45a9-a784-7fe01badf715.jpg',
    number: '07',
  },
  {
    name: 'Dragon Chubbs',
    image: 'https://i.ibb.co.com/KpghpM3J/6e4b4a92-582a-455a-86a2-09c59ef3b43c.jpg',
    number: '08',
  },
  {
    name: 'Winter Chubbs',
    image: 'https://i.ibb.co.com/23XgDPSJ/b650ea56-5876-4676-9308-2b7d056b4e33.jpg',
    number: '09',
  },
  {
    name: 'Lava Chubbs',
    image: 'https://i.ibb.co.com/pjsRfCLr/affb013c-2eed-4210-9c2b-ccd0265a3d45.jpg',
    number: '10',
  },
  {
    name: 'Galaxy Chubbs',
    image: 'https://i.ibb.co.com/sprwLmCv/13a7c060-2d49-470d-93a4-f19ee8444fe3.jpg',
    number: '11',
  },
];

export const LOGO_SRC =
  'https://i.ibb.co.com/Q3B5LKV5/aaaa3496-d60c-44bd-8f84-12a4d64e3640.jpg';

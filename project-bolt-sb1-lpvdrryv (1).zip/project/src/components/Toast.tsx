import { useEffect, useState } from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

export type ToastState = {
  message: string;
  isError: boolean;
  id: number;
};

type ToastProps = {
  toast: ToastState | null;
};

export default function Toast({ toast }: ToastProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!toast) return;
    setVisible(true);
    const t = setTimeout(() => setVisible(false), 3800);
    return () => clearTimeout(t);
  }, [toast]);

  if (!toast) return null;

  return (
    <div
      className={`fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-3.5 rounded-3xl shadow-2xl flex items-center gap-x-3 z-[200] border transition-all duration-300 ${
        toast.isError
          ? 'bg-red-900/90 border-red-500/40 text-red-200'
          : 'bg-[#111116] border-[#ccff00]/40 text-white'
      } ${visible ? 'toast-enter' : 'opacity-0'}`}
    >
      {toast.isError ? (
        <AlertCircle className="w-5 h-5 text-red-400" />
      ) : (
        <CheckCircle className="w-5 h-5 text-[#ccff00]" />
      )}
      <span className="font-medium">{toast.message}</span>
    </div>
  );
}

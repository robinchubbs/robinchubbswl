const PHASES = [
  {
    phase: 'PHASE 01',
    title: 'Genesis Collection',
    desc: 'Launch the 4,444 unique CHUBBS NFT Collection, each featuring handcrafted traits, immersive themes, and a distinctive identity.',
    active: true,
  },
  {
    phase: 'PHASE 02',
    title: 'Community Token',
    desc: 'Launch the CHUBBS memecoin to strengthen community engagement and expand the ecosystem through Web3 initiatives.',
  },
  {
    phase: 'PHASE 03',
    title: 'Digital & Physical Merch',
    desc: 'Introduce exclusive stickers, apparel, collectibles, and official CHUBBS merchandise for the community.',
  },
  {
    phase: 'PHASE 04',
    title: 'CHUBBS Mini Game',
    desc: 'Develop a browser-based mini game where holders can explore the CHUBBS Universe and interact with their favorite characters.',
  },
  {
    phase: 'PHASE 05',
    title: 'Web3 Ecosystem Expansion',
    desc: 'Expand the CHUBBS Universe through partnerships, collaborations, new digital experiences, and community-driven innovation.',
  },
];

export default function Roadmap() {
  return (
    <section id="roadmap" className="max-w-6xl mx-auto px-6 py-20">
      <div className="text-center mb-14">
        <div className="text-[#ccff00] text-sm font-bold tracking-[3px]">
          THE JOURNEY AHEAD
        </div>
        <h2 className="font-display text-6xl tracking-tighter mt-2">Roadmap</h2>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {PHASES.map((p) => (
          <div
            key={p.phase}
            className="roadmap-step group p-7 rounded-3xl bg-[#111116] border border-white/10 hover:border-[#ccff00]/40"
          >
            <div className="flex items-center gap-x-3 mb-4">
              <div
                className={`px-4 py-1.5 rounded-2xl text-xs font-extrabold tracking-wider ${
                  p.active
                    ? 'bg-[#ccff00] text-[#0a0a0f]'
                    : 'bg-white/10 text-white'
                }`}
              >
                {p.phase}
              </div>
            </div>
            <h4 className="font-display text-2xl tracking-tight mb-3 group-hover:text-[#ccff00] transition-colors">
              {p.title}
            </h4>
            <p className="text-white/70 text-[15px]">{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

import { ArrowRight } from 'lucide-react';

type CTAProps = {
  onApply: () => void;
};

export default function CTA({ onApply }: CTAProps) {
  return (
    <div className="max-w-4xl mx-auto px-6 pb-20">
      <div className="rounded-3xl bg-gradient-to-br from-[#111116] to-[#0a0a0f] border border-white/10 p-10 md:p-14 text-center">
        <h3 className="font-display text-5xl tracking-tighter mb-4">
          Ready to join the Chubbs family?
        </h3>
        <p className="text-white/60 mb-8 max-w-md mx-auto">
          Apply for whitelist now and be among the first to own a piece of the
          Chubbs universe.
        </p>

        <button
          onClick={onApply}
          className="neon-button inline-flex items-center justify-center px-14 py-4 text-lg rounded-3xl font-extrabold gap-x-3"
        >
          <span>APPLY FOR WHITELIST</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

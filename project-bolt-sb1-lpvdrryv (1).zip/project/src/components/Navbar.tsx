import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Twitter } from './icons';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navLinks = [
    { label: 'Collection', href: '#collection' },
    { label: 'Vision', href: '#vision' },
    { label: 'Roadmap', href: '#roadmap' },
  ];

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0a0a0f]/95 backdrop-blur-lg border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-x-3"
          >
            <img
              src="https://i.ibb.co.com/Q3B5LKV5/aaaa3496-d60c-44bd-8f84-12a4d64e3640.jpg"
              alt="RobinChubbs Logo"
              className="w-11 h-11 rounded-2xl object-cover ring-2 ring-[#ccff00]/30"
            />
            <div>
              <span className="font-display text-3xl tracking-tighter font-semibold">
                Robin
              </span>
              <span className="font-display text-3xl tracking-tighter font-semibold chubbs-yellow">
                Chubbs
              </span>
            </div>
          </button>

          <div className="hidden md:flex items-center gap-x-10 text-sm font-medium">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="hover:text-[#ccff00] transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-x-4">
            <a
              href="https://x.com/robinchubbs"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-x-2 px-5 py-2.5 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all text-sm font-medium"
            >
              <Twitter className="w-4 h-4" />
              <span className="hidden sm:inline">Follow us</span>
            </a>

            <button
              className="md:hidden w-11 h-11 flex items-center justify-center text-xl"
              onClick={() => setMobileOpen((v) => !v)}
            >
              {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden pb-6 flex flex-col gap-y-3 border-t border-white/10 pt-4">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-left text-base font-medium hover:text-[#ccff00] transition-colors py-1"
              >
                {link.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}

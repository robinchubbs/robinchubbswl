import { Ticket, ArrowDown, Users, Globe } from 'lucide-react';
import { LOGO_SRC } from '../data/nfts';

type HeroProps = {
  onApply: () => void;
};

export default function Hero({ onApply }: HeroProps) {
  return (
    <header className="relative min-h-[100dvh] flex items-center justify-center pt-20 overflow-hidden subtle-grid">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/90 to-[#0a0a0f]" />

      <FallingLogos />

      <div className="relative z-20 max-w-5xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-x-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 mb-6">
          <div className="w-2 h-2 bg-[#ccff00] rounded-full animate-pulse" />
          <span className="text-xs font-semibold tracking-[2px] text-[#ccff00]">
            GENESIS COLLECTION • 4,444 NFTs
          </span>
        </div>

        <h1 className="font-display text-7xl md:text-8xl leading-[0.92] tracking-tighter font-bold mb-4">
          THE CHUBBS
          <br />
          ARE <span className="chubbs-yellow">HERE</span>.
        </h1>

        <p className="max-w-md mx-auto text-xl text-white/70 mb-10">
          A community-driven NFT &amp; meme ecosystem built for collectors,
          holders, and the next generation of Web3.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onApply}
            className="neon-button px-10 py-4 text-lg rounded-3xl font-bold flex items-center justify-center gap-x-3 w-full sm:w-auto"
          >
            <Ticket className="w-5 h-5" />
            <span>APPLY FOR WHITELIST</span>
          </button>

          <button
            onClick={() =>
              document
                .querySelector('#collection')
                ?.scrollIntoView({ behavior: 'smooth' })
            }
            className="px-8 py-4 rounded-3xl border border-white/20 hover:bg-white/5 font-semibold flex items-center justify-center gap-x-2 transition-all w-full sm:w-auto"
          >
            <span>Explore Collection</span>
            <ArrowDown className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center justify-center gap-x-8 mt-12 text-sm">
          <div className="flex items-center gap-x-2">
            <Users className="w-4 h-4 text-[#ccff00]" />
            <span className="text-white/60">Community First</span>
          </div>
          <div className="flex items-center gap-x-2">
            <Globe className="w-4 h-4 text-[#ccff00]" />
            <span className="text-white/60">Web3 Native</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center z-20">
        <div className="text-[10px] tracking-[3px] text-white/40 mb-1">
          SCROLL TO EXPLORE
        </div>
        <ArrowDown className="w-4 h-4 text-white/40 animate-bounce" />
      </div>
    </header>
  );
}

function FallingLogos() {
  const logos = Array.from({ length: 18 }, (_, i) => {
    const left = Math.random() * 100;
    const size = 45 + Math.random() * 55;
    const duration = 7 + Math.random() * 11;
    const delay = Math.random() * -25;
    const opacity = 0.45 + Math.random() * 0.4;
    const reverse = Math.random() > 0.5;
    return { id: i, left, size, duration, delay, opacity, reverse };
  });

  return (
    <div className="absolute inset-0 pointer-events-none z-10">
      {logos.map((l) => (
        <img
          key={l.id}
          src={LOGO_SRC}
          alt=""
          className="falling-logo"
          style={{
            left: `${l.left}vw`,
            width: `${l.size}px`,
            height: `${l.size}px`,
            animationDuration: `${l.duration}s`,
            animationDelay: `${l.delay}s`,
            opacity: l.opacity,
            animationDirection: l.reverse ? 'reverse' : 'normal',
          }}
        />
      ))}
    </div>
  );
}

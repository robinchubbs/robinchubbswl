const STATS = [
  { value: '4,444', label: 'UNIQUE CHUBBS' },
  { value: '11', label: 'EPIC THEMES' },
  { value: '100%', label: 'COMMUNITY DRIVEN' },
  { value: '∞', label: 'FUTURE UTILITY' },
];

export default function StatsBar() {
  return (
    <div className="border-b border-white/10 bg-[#111116]">
      <div className="max-w-7xl mx-auto px-6 py-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {STATS.map((s) => (
            <div key={s.label}>
              <div className="text-4xl font-bold font-display tracking-tighter stat-number">
                {s.value}
              </div>
              <div className="text-xs text-white/50 tracking-widest">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

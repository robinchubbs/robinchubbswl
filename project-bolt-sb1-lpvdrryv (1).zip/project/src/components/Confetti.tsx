import { useEffect, useRef } from 'react';

const COLORS = ['#ccff00', '#ffcc00', '#ffffff'];

type ConfettiProps = {
  trigger: number;
};

export default function Confetti({ trigger }: ConfettiProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (trigger === 0) return;
    const container = containerRef.current;
    if (!container) return;

    const count = 80;
    for (let i = 0; i < count; i++) {
      const el = document.createElement('div');
      el.style.position = 'fixed';
      el.style.left = Math.random() * window.innerWidth + 'px';
      el.style.top = '-10px';
      el.style.width = '8px';
      el.style.height = '8px';
      el.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
      el.style.backgroundColor =
        COLORS[Math.floor(Math.random() * COLORS.length)];
      el.style.opacity = String(Math.random() * 0.8 + 0.4);
      el.style.zIndex = '99999';
      el.style.pointerEvents = 'none';
      document.body.appendChild(el);

      const duration = Math.random() * 2800 + 2200;
      const angle = Math.random() * 60 - 20;

      el.animate(
        [
          {
            transform: 'translateY(0) rotate(0deg)',
            opacity: el.style.opacity,
          },
          {
            transform: `translateY(${window.innerHeight + 100}px) rotate(${
              angle * 8
            }deg)`,
            opacity: 0,
          },
        ],
        { duration, easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)' }
      ).onfinish = () => el.remove();
    }
  }, [trigger]);

  return <div ref={containerRef} className="hidden" />;
}

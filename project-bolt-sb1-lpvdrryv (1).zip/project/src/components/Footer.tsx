import { Twitter } from './icons';

export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-9">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-y-4 text-sm text-white/50">
        <div>© 2026 Chubbs — powered by community</div>

        <div className="flex items-center gap-x-6">
          <a
            href="https://x.com/robinchubbs"
            target="_blank"
            rel="noreferrer"
            className="hover:text-white flex items-center gap-x-2 transition-colors"
          >
            <Twitter className="w-4 h-4" />
            <span>@robinchubbs</span>
          </a>
          <div className="w-px h-3 bg-white/20" />
          <span className="text-xs">Built with ❤️ for the Chubbs</span>
        </div>
      </div>
    </footer>
  );
}

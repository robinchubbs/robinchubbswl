import { ArrowUpRight } from 'lucide-react';
import { NFTS } from '../data/nfts';
import { Twitter } from './icons';

export default function Collection() {
  return (
    <section id="collection" className="max-w-7xl mx-auto px-6 pb-24">
      <div className="flex items-end justify-between mb-10">
        <div>
          <div className="text-[#ccff00] text-sm font-bold tracking-[3px]">
            GENESIS COLLECTION
          </div>
          <h2 className="font-display text-6xl tracking-tighter">
            Meet the Chubbs
          </h2>
        </div>
        <a
          href="https://x.com/robinchubbs"
          target="_blank"
          rel="noreferrer"
          className="hidden md:flex items-center gap-x-2 text-sm font-medium hover:text-[#ccff00] transition-colors"
        >
          VIEW ALL ON X <ArrowUpRight className="w-4 h-4 ml-1.5" />
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
        {NFTS.map((nft) => (
          <div
            key={nft.number}
            className="nft-card group bg-[#111116] rounded-3xl overflow-hidden border border-white/10"
          >
            <div className="aspect-square overflow-hidden bg-black">
              <img
                src={nft.image}
                alt={nft.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
            </div>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-lg">{nft.name}</div>
                  <div className="text-xs text-white/50">Genesis • Epic</div>
                </div>
                <div className="px-3 py-1 rounded-full bg-white/5 text-[10px] font-mono">
                  {nft.number}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-8">
        <p className="text-white/50 text-sm">
          Each Chubbs is 1-of-1 with handcrafted traits and unique personality.
        </p>
      </div>
    </section>
  );
}

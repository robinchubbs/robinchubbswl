import { useEffect, useState } from 'react';
import { X, Loader2, Ticket } from 'lucide-react';
import { Twitter } from './icons';
import { supabase } from '../lib/supabase';

type WhitelistModalProps = {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onToast: (message: string, isError?: boolean) => void;
};

export default function WhitelistModal({
  open,
  onClose,
  onSuccess,
  onToast,
}: WhitelistModalProps) {
  const [twitter, setTwitter] = useState('');
  const [wallet, setWallet] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => {
        document.getElementById('wl-twitter')?.focus();
      }, 300);
      return () => clearTimeout(t);
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const trimmedTwitter = twitter.trim();
    const trimmedWallet = wallet.trim();

    if (!trimmedTwitter || !trimmedWallet) {
      onToast('Please fill in all fields', true);
      return;
    }

    setSubmitting(true);

    try {
      const { error } = await supabase.from('whitelist_applications').insert({
        twitter: trimmedTwitter,
        wallet_address: trimmedWallet,
        status: 'pending',
      });

      if (error) throw error;

      setTwitter('');
      setWallet('');
      onClose();
      onToast("Application submitted! We'll contact you soon.");
      onSuccess();
    } catch (err) {
      console.error('Whitelist submission error:', err);
      onToast('Something went wrong. Please try again later.', true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[100] flex items-center justify-center p-6"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="modal-pop w-full max-w-lg bg-[#111116] border border-white/10 rounded-3xl overflow-hidden"
      >
        <div className="px-8 pt-8 pb-5 flex items-center justify-between border-b border-white/10">
          <div>
            <div className="font-display text-3xl tracking-tighter">
              Apply for Whitelist
            </div>
            <div className="text-xs text-[#ccff00] font-medium tracking-widest">
              ROBINCHUBBS GENESIS
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center text-2xl text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8">
          <form onSubmit={handleSubmit}>
            <div className="space-y-5">
              <div>
                <label className="text-xs font-semibold tracking-wider text-white/60 block mb-1.5">
                  TWITTER / X HANDLE
                </label>
                <div className="relative">
                  <div className="absolute left-5 top-1/2 -translate-y-1/2 text-white/40">
                    <Twitter className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    id="wl-twitter"
                    value={twitter}
                    onChange={(e) => setTwitter(e.target.value)}
                    placeholder="@yourhandle"
                    required
                    className="w-full bg-[#0a0a0f] border border-white/20 focus:border-[#ccff00] rounded-2xl pl-12 pr-5 py-3.5 outline-none text-white placeholder:text-white/40 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold tracking-wider text-white/60 block mb-1.5">
                  WALLET ADDRESS
                </label>
                <input
                  type="text"
                  value={wallet}
                  onChange={(e) => setWallet(e.target.value)}
                  placeholder="0x... or aptos wallet"
                  required
                  className="w-full bg-[#0a0a0f] border border-white/20 focus:border-[#ccff00] rounded-2xl px-5 py-3.5 outline-none text-white placeholder:text-white/40 font-mono text-sm transition-colors"
                />
              </div>
            </div>

            <div className="mt-8">
              <button
                type="submit"
                disabled={submitting}
                className="neon-button w-full py-4 rounded-3xl text-base font-extrabold flex items-center justify-center gap-x-2 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>SUBMITTING...</span>
                  </>
                ) : (
                  <>
                    <Ticket className="w-5 h-5" />
                    <span>SUBMIT APPLICATION</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-center text-[10px] text-white/40 mt-4">
              We'll review your application and notify you via Twitter DM.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

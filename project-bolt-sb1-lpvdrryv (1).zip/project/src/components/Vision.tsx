import { Eye, Target } from 'lucide-react';

const MISSIONS = [
  'Build a timeless mascot that people instantly recognize across NFTs, games, merchandise, and digital media.',
  'Grow a community where every collector helps shape the future of the CHUBBS universe.',
  'Craft high-quality artwork, meaningful traits, and memorable stories for every CHUBBS.',
  'Continuously introduce new worlds, characters, and experiences while preserving the original CHUBBS identity.',
  'Focus on sustainable growth, transparency, and innovation rather than short-term hype.',
];

export default function Vision() {
  return (
    <section
      id="vision"
      className="bg-[#111116] py-20 border-y border-white/10"
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <div className="flex items-center gap-x-3 mb-5">
              <div className="w-9 h-9 rounded-2xl bg-[#ccff00]/10 flex items-center justify-center">
                <Eye className="w-5 h-5 text-[#ccff00]" />
              </div>
              <div className="text-[#ccff00] font-bold tracking-[2px] text-sm">
                VISION
              </div>
            </div>
            <h3 className="font-display text-4xl tracking-tighter leading-none mb-6">
              To build CHUBBS into a globally recognized Web3 character brand.
            </h3>
            <p className="text-lg text-white/70">
              Connecting creativity, digital ownership, and community through
              unique collectibles and immersive experiences.
            </p>
          </div>

          <div>
            <div className="flex items-center gap-x-3 mb-5">
              <div className="w-9 h-9 rounded-2xl bg-[#ccff00]/10 flex items-center justify-center">
                <Target className="w-5 h-5 text-[#ccff00]" />
              </div>
              <div className="text-[#ccff00] font-bold tracking-[2px] text-sm">
                MISSION
              </div>
            </div>

            <div className="space-y-5 text-[15px]">
              {MISSIONS.map((m, i) => (
                <div key={i} className="flex gap-4">
                  <div className="mt-1 w-6 h-6 flex-shrink-0 rounded-full bg-white/10 flex items-center justify-center text-xs font-mono text-[#ccff00]">
                    {String(i + 1).padStart(2, '0')}
                  </div>
                  <p className="text-white/70">{m}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

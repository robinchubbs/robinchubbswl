export default function About() {
  return (
    <section className="max-w-4xl mx-auto px-6 py-20 text-center">
      <div className="max-w-2xl mx-auto">
        <div className="inline-block px-4 py-1 rounded-full bg-[#ccff00]/10 text-[#ccff00] text-xs font-bold tracking-widest mb-4">
          THE STORY
        </div>
        <h2 className="font-display text-5xl tracking-tighter mb-6">
          Built by the community.
          <br />
          For the community.
        </h2>
        <p className="text-xl text-white/70 leading-relaxed">
          RobinChubbs is a community-driven NFT &amp; meme ecosystem built for
          collectors, holders, and the next generation of Web3. Every Chubbs
          carries unique traits, immersive stories, and a piece of the growing
          Chubbs universe.
        </p>
      </div>
    </section>
  );
}

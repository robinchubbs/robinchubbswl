/*
# Remove name column from whitelist_applications

1. Modified Tables
- `whitelist_applications`
- Dropped the `name` column (no longer collected in the whitelist form)
2. Security
- No RLS policy changes — existing INSERT and SELECT policies remain unchanged.
3. Important Notes
- This is a destructive column drop. Any existing name data will be permanently removed.
- The frontend whitelist form now only collects twitter handle and wallet address.
*/

ALTER TABLE whitelist_applications DROP COLUMN IF EXISTS name;
